import XCTest

import ApolloCodegenTests

var tests = [XCTestCaseEntry]()
tests += ApolloCodegenTests.allTests()
XCTMain(tests)
