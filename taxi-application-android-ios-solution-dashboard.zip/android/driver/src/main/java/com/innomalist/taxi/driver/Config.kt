package com.innomalist.taxi.driver

class Config {
    companion object {
        const val Backend = "http://95.217.23.13:4002/"
//            const val Backend = "http://10.0.2.2:3002/"
    }
}