package com.innomalist.taxi.driver.activities.splash.repository

interface LocationRepository {
}