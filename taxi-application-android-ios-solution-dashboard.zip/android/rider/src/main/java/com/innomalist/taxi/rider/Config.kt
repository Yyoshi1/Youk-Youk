package com.innomalist.taxi.rider

class Config {
    companion object {
        const val Backend = "http://95.217.23.13:4000/"
//        const val Backend = "http://10.0.2.2:3001/"
    }
}